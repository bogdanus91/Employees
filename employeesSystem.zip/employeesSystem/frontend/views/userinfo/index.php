<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Мои данные';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="userinfo-index">

    <h1><?= Html::encode($this->title) ?></h1>


    <?php Pjax::begin(); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
            //'username',
            //'auth_key',
            //'password_hash',
            //'password_reset_token',
            //'email:email',
            //'status',
            //'created_at',
            //'updated_at',
            //'verification_token',
            //'cv',
            'vacansy.name',
            //'role',
            'department.name',
            //'saloryType',
            [
                'attribute' => 'saloryType',

                'value' => function ($data) {

                    if ($data->saloryType==0)
                    {
                        return "Почасовая";
                    }
                    if ($data->saloryType==1)
                    {
                        return "Фексированная";
                    }

                    //  return Html::a(Html::encode($data->DocumentName), Url::to(['download', 'dfile' => $data->DocumentName],['data-pjax' => '0']));
                },
                'format' => 'raw',
            ],

            'salory',
            'startDate',
            //'phone',
            //'name',

            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
