<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "vacansys".
 *
 * @property int $id
 * @property string $name Название вакансии
 * @property string $description Подробное описание вакансии
 *
 * @property User[] $users
 */
class Vacansys extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'vacansys';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'description'], 'required'],
            [['description'], 'string'],
            [['name'], 'string', 'max' => 255],
       ['published','boolean'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название вакансии',
            'description' => 'Подробное описание вакансии',
            'published' => 'Опубликовано на сайте',

        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(User::className(), ['vacansy_id' => 'id']);
    }
}
