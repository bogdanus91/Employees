<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Сотрудники';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="userinfo-index">

    <h1><?= Html::encode($this->title) ?></h1>




    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            
            'name',
           // 'cv',
          [
            'attribute' => 'cv',

            'value' => function ($data) {
               return Html::a(Html::encode($data->cv), Url::to(['download', 'dfile' => $data->cv],['data-pjax' => '0']));
           },
           'format' => 'raw',
       ],

            'email',
            //'email:email',
            //'status',
            //'created_at',
            //'updated_at',
            //'verification_token',
            //'cv',

            'vacansy.name',
            //'role',
            'department.name',
            //'saloryType',
            //'salory',
            //'startDate',
            'phone',
            //'name',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
