<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model backend\models\Userinfo */
/* @var $form yii\widgets\ActiveForm */
?>
<?php
$departments = common\models\Departments::find()->orderBy('name')->asArray()->all();
$list=ArrayHelper::map($departments, 'id', 'name');
?>

<div class="userinfo-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'username')->hiddenInput()->label(false)?>

    <?= $form->field($model, 'auth_key')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'password_hash')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'password_reset_token')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'email')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'status')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'created_at')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'updated_at')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'verification_token')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'cv')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'vacansy_id')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'role')->dropDownList([
        '0' => 'Сотрудник',
        '1' => 'Администратор'

    ]); ?>

    <?= $form->field($model, 'department_id')->dropDownList($list)->label('Отдел') ?>

    <?= $form->field($model, 'saloryType')->dropDownList([
        '0' => 'Почасовая',
        '1' => 'Фиксированная'

    ]); ?>

    <?= $form->field($model, 'salory')->textInput() ?>

    <?= $form->field($model, 'startDate')->textInput(['type' => 'date']) ?>

    <?= $form->field($model, 'phone')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'name')->hiddenInput()->label(false) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
