<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\url;
/* @var $this yii\web\View */
/* @var $model backend\models\Userinfo */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Сотрудники', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="userinfo-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Редактировать', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Удалить', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'username',
           // 'auth_key',
           // 'password_hash',
            //'password_reset_token',
            //'email:email',
            //'status',
            //'created_at',
            //'updated_at',
            //'verification_token',
            //'cv',
            [
                'attribute' => 'cv',

                'value' => function ($data) {
                    return Html::a(Html::encode($data->cv), Url::to(['download', 'dfile' => $data->cv],['data-pjax' => '0']));
                },
                'format' => 'raw',
            ],
            'vacansy.name',
          //  'role',
            [
                'attribute' => 'role',

                'value' => function ($data) {

                    if ($data->role==0)
                    {
                        return "Сотрудник";
                    }
                    if ($data->role==1)
                    {
                        return "Администратор";
                    }

                    //  return Html::a(Html::encode($data->DocumentName), Url::to(['download', 'dfile' => $data->DocumentName],['data-pjax' => '0']));
                },
                'format' => 'raw',
            ],
            'department.name',
            //'saloryType',
            [
                'attribute' => 'saloryType',

                'value' => function ($data) {

                    if ($data->saloryType==0)
                    {
                        return "Почасовая";
                    }
                    if ($data->saloryType==1)
                    {
                        return "Фексированная";
                    }

                    //  return Html::a(Html::encode($data->DocumentName), Url::to(['download', 'dfile' => $data->DocumentName],['data-pjax' => '0']));
                },
                'format' => 'raw',
            ],
            'salory',
            'startDate',
            'phone',
            'name',
        ],
    ]) ?>

</div>
