<?php

namespace backend\models;

use Yii;
use common\models\Departments;
use common\models\Vacansys;
/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $username
 * @property string $auth_key
 * @property string $password_hash
 * @property string $password_reset_token
 * @property string $email
 * @property int $status
 * @property int $created_at
 * @property int $updated_at
 * @property string $verification_token
 * @property string $cv Файл резюме
 * @property int $vacansy_id Вакансия
 * @property int $role Роль в системе
 * @property int $department_id Отдел
 * @property int $saloryType Тип оплаты
 * @property double $salory Заработная плата
 * @property string $startDate Дата начала работы
 * @property string $phone Телефон
 * @property string $name ФИО
 *
 * @property Departments $department
 * @property Vacansys $vacansy
 */
class Userinfo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
          //  [['username', 'auth_key', 'password_hash', 'email', 'created_at', 'updated_at', 'cv', 'vacansy_id', 'phone', 'name'], 'required'],
            [['status', 'created_at', 'updated_at', 'vacansy_id', 'role', 'department_id', 'saloryType'], 'integer'],
            [['salory'], 'number'],
            [['startDate'], 'safe'],
            [['username', 'password_hash', 'password_reset_token', 'email', 'verification_token', 'cv', 'phone', 'name'], 'string', 'max' => 255],
            [['auth_key'], 'string', 'max' => 32],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['password_reset_token'], 'unique'],
            [['department_id'], 'exist', 'skipOnError' => true, 'targetClass' => Departments::className(), 'targetAttribute' => ['department_id' => 'id']],
            [['vacansy_id'], 'exist', 'skipOnError' => true, 'targetClass' => Vacansys::className(), 'targetAttribute' => ['vacansy_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'auth_key' => 'Auth Key',
            'password_hash' => 'Password Hash',
            'password_reset_token' => 'Password Reset Token',
            'email' => 'Email',
            'status' => 'Статус',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'verification_token' => 'Verification Token',
            'cv' => 'Файл резюме',
            'vacansy_id' => 'Вакансия',
            'role' => 'Роль в системе',
            'department_id' => 'Отдел',
            'saloryType' => 'Тип оплаты',
            'salory' => 'Заработная плата',
            'startDate' => 'Дата начала работы',
            'phone' => 'Телефон',
            'name' => 'ФИО',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDepartment()
    {
        return $this->hasOne(Departments::className(), ['id' => 'department_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVacansy()
    {
        return $this->hasOne(Vacansys::className(), ['id' => 'vacansy_id']);
    }
}
